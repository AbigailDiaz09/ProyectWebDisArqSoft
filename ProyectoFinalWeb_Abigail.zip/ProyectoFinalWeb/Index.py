from flask import Flask, render_template, request, redirect

app = Flask(__name__)

# Simulando la funcionalidad de la base de datos y CRUD
class CRUD:
    def verificar_login(self, user, password):
        # Lógica de verificación de login (simulada)
        return user == "usuario" and password == "contrasena"

crud = CRUD()

@app.route('/', methods=['GET', 'POST'])
def login():
    error = ''

    if request.method == 'POST':
        user = request.form['user']
        password = request.form['pass']

        # Verificar el usuario y la contraseña utilizando el método verificarLogin
        valid_login = crud.verificar_login(user, password)

        if valid_login:
            # Usuario y contraseña válidos, redirigir al menú de opciones
            return redirect('/menu')
        else:
            # Usuario y/o contraseña inválidos, mostrar mensaje de error
            error = 'Usuario y/o contraseña incorrectos'

    return render_template('login.html', error=error)

@app.route('/menu')
def menu():
    # Lógica para la página de menú (puedes personalizar según tus necesidades)
    return render_template('menu.html')

if __name__ == '__main__':
    app.run(debug=True)
