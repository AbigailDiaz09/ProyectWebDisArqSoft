import os
import sys
import pymysql.cursors

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

if os.path.exists('../modelo/SingeltonDB.py'):
    from modelo.SingeltonDB import SingeltonDB
elif os.path.exists('modelo/SingeltonDB.py'):
    from modelo.SingeltonDB import SingeltonDB
else:
    print('El archivo SingeltonDB.py no se encuentra en ninguna ruta válida.')
    sys.exit(1)

class CRUD:
    def __init__(self):
        self.db = SingeltonDB.getInstance().getDB()

    @staticmethod
    def getInstance():
        if CRUD.instance is None:
            CRUD.instance = CRUD()
        return CRUD.instance

    ########################################################
    # TABLA LOGION_USUARIO#
    ########################################################

    ############################
    # VERIFICAR EL LOGIN#SIN TRY Y CATCH
    ############################
    def verificarLogin(self, usuario, password):
        stmt = self.db.prepare("SELECT * FROM login_usuario WHERE usuario = :usuario AND pass = :pass")
        stmt.bind_param(':usuario', usuario)
        stmt.bind_param(':pass', password)
        stmt.execute()
        usuarioEncontrado = stmt.fetch(PDO.FETCH_ASSOC)

        if usuarioEncontrado:
            # El usuario y la contraseña son correctos
            return True
        else:
            # El usuario o la contraseña son incorrectos
            return False

    ############################
    # SELECT USUARIO#
    ############################
    def seleccionarUsuarios(self):
        try:
            stmt = self.db.prepare("SELECT * FROM login_usuario")
            stmt.execute()
            usuarios = stmt.fetch_all(PDO.FETCH_ASSOC)

            return usuarios
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # CREAR USUARIO#
    ############################
    def crearUsuario(self, usuario, password):
        try:
            stmt = self.db.prepare("INSERT INTO login_usuario (usuario, pass) VALUES (:usuario, :pass)")
            stmt.bind_param(':usuario', usuario)
            stmt.bind_param(':pass', password)
            stmt.execute()
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # ACTUALIZAR USUARIO#
    ############################
    def actualizarUsuario(self, id, usuario, password):
        try:
            stmt = self.db.prepare("UPDATE login_usuario SET usuario = :usuario, pass = :pass WHERE id = :id")
            stmt.bind_param(':id', id)
            stmt.bind_param(':usuario', usuario)
            stmt.bind_param(':pass', password)
            stmt.execute()
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # ELIMINAR USUARIO#
    ############################
    def eliminarUsuario(self, id):
        try:
            stmt = self.db.prepare("DELETE FROM login_usuario WHERE id = :id")
            stmt.bind_param(':id', id)
            stmt.execute()
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ########################################################
    # TABLA MUNICIPIO#
    ########################################################

    ############################
    # SELECT MUNICIPIO#
    ############################
    def seleccionarMunicipios(self):
        try:
            stmt = self.db.prepare("SELECT * FROM municipio")
            stmt.execute()
            municipios = stmt.fetch_all(PDO.FETCH_ASSOC)

            return municipios
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ########################################################
    # TABLA LOCALIDADES#
    ########################################################

    ############################
    # SELECT LOCALIDAD#
    ############################
    def seleccionarLocalidades(self):
        try:
            stmt = self.db.prepare("SELECT * FROM localidades")
            stmt.execute()
            localidades = stmt.fetch_all(PDO.FETCH_ASSOC)

            return localidades
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    def seleccionarLocalidadesXMunicipio(self, idmunicipio):
        try:
            stmt = self.db.prepare("SELECT nombre_localidad FROM localidades WHERE municipio_idmunicipio = :idmunicipio")
            stmt.bind_param(':idmunicipio', idmunicipio)
            stmt.execute()
            localidades = stmt.fetch_all()

            return localidades
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    def obtenerIdLocalidadPorNombre(self, nombre_localidad):
        try:
            stmt = self.db.prepare("SELECT idlocalidades FROM localidades WHERE nombre_localidad = :nombre_localidad")
            stmt.bind_param(':nombre_localidad', nombre_localidad)
            stmt.execute()
            id_localidad = stmt.fetch_column()

            return id_localidad
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ########################################################
    # TABLA HABITANTE#
    ########################################################

    ############################
    # CREAR HABITANTE#
    ############################
    def crearHabitante(self, idhabitante, nombre, edad, sexo, edo_civil, nivel_educativo, ingresos, nacionalidad, vivienda_id):
        try:
            stmt = self.db.prepare(
                "INSERT INTO habitante (idhabitante, nombre, edad, sexo, edo_civil, nivel_educativo, ingresos, nacionalidad, vivienda_idvivienda) VALUES (:idhabitante, :nombre, :edad, :sexo, :edo_civil, :nivel_educativo, :ingresos, :nacionalidad, :vivienda_id)")
            stmt.bind_param(':idhabitante', idhabitante)
            stmt.bind_param(':nombre', nombre)
            stmt.bind_param(':edad', edad)
            stmt.bind_param(':sexo', sexo)
            stmt.bind_param(':edo_civil', edo_civil)
            stmt.bind_param(':nivel_educativo', nivel_educativo)
            stmt.bind_param(':ingresos', ingresos)
            stmt.bind_param(':nacionalidad', nacionalidad)
            stmt.bind_param(':vivienda_id', vivienda_id)
            stmt.execute()
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # SELECT HABITANTE#
    ############################
    def seleccionarHabitantes(self):
        try:
            stmt = self.db.prepare("SELECT * FROM habitante")
            stmt.execute()
            habitantes = stmt.fetch_all(PDO.FETCH_ASSOC)
            return habitantes
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # SELECT HABITANTE POR ID#
    ############################
    def seleccionarHabitantePorId(self, id):
        try:
            stmt = self.db.prepare("SELECT * FROM habitante WHERE idhabitante = :id")
            stmt.bind_param(':id', id)
            stmt.execute()
            habitante = stmt.fetch(PDO.FETCH_ASSOC)
            return habitante
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # ACTUALIZAR HABITANTE POR ID#
    ############################
    def actualizarHabitante(self, id, nombre, edad, sexo, edo_civil, nivel_educativo, ingresos, nacionalidad, vivienda_id):
        try:
            stmt = self.db.prepare(
                "UPDATE habitante SET nombre = :nombre, edad = :edad, sexo = :sexo, edo_civil = :edo_civil, nivel_educativo = :nivel_educativo, ingresos = :ingresos, nacionalidad = :nacionalidad, vivienda_idvivienda = :vivienda_id WHERE idhabitante = :id")
            stmt.bind_param(':id', id)
            stmt.bind_param(':nombre', nombre)
            stmt.bind_param(':edad', edad)
            stmt.bind_param(':sexo', sexo)
            stmt.bind_param(':edo_civil', edo_civil)
            stmt.bind_param(':nivel_educativo', nivel_educativo)
            stmt.bind_param(':ingresos', ingresos)
            stmt.bind_param(':nacionalidad', nacionalidad)
            stmt.bind_param(':vivienda_id', vivienda_id)
            stmt.execute()
            return True
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # BORRAR HABITANTE POR ID#
    ############################
    def borrarHabitante(self, id):
        try:
            stmt = self.db.prepare("DELETE FROM habitante WHERE idhabitante = :id")
            stmt.bind_param(':id', id)
            stmt.execute()
            return True
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ########################################################
    # TABLA VIVIENDA_OCUPACION#
    ########################################################

    ############################
    # CREAR VIVIENDA_OCUPACION#
    ############################
    def crearViviendaOcupacion(self, vivienda_id, ocupacion_id):
        try:
            stmt = self.db.prepare(
                "INSERT INTO idvivienda_ocupacion (vivienda_idvivienda, ocupacion_idocupacion) VALUES (:vivienda_id, :ocupacion_id)")
            stmt.bind_param(':vivienda_id', vivienda_id)
            stmt.bind_param(':ocupacion_id', ocupacion_id)
            stmt.execute()
            return True
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # ACTUALIZAR VIVIENDA_OCUPACION#
    ############################
    def actualizarViviendaOcupacion(self, id, vivienda_id, ocupacion_id):
        try:
            stmt = self.db.prepare(
                "UPDATE idvivienda_ocupacion SET vivienda_idvivienda = :vivienda_id, ocupacion_idocupacion = :ocupacion_id WHERE idvivienda_ocupacion = :id")
            stmt.bind_param(':id', id)
            stmt.bind_param(':vivienda_id', vivienda_id)
            stmt.bind_param(':ocupacion_id', ocupacion_id)
            stmt.execute()
            return True
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # BORRAR ULTIMO REGISTRO DE VIVIENDA_OCUPACION#
    ############################
    def borrarUltimaViviendaOcupacion(self):
        try:
            stmt = self.db.prepare("DELETE FROM idvivienda_ocupacion WHERE idvivienda_ocupacion = LAST_INSERT_ID()")
            stmt.execute()
            return True
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ########################################################
    # TABLA VIVIENDA#
    ########################################################

    ############################
    # AGREGAR VIVIENDA#
    ############################
    def crearVivienda(self, tipo, material, saneamiento, agua, luz, drenaje, tendencia, direccion, num_habitaciones,
                      num_banios, idlocalidades, idmunicipio):
        try:
            stmt = self.db.prepare(
                "INSERT INTO vivienda (tipo_vivienda, material, saneamiento, agua, luz, drenaje, tendencia, direccion, num_habitaciones, num_banios, localidades_idlocalidades, localidades_municipio_idmunicipio) VALUES (:tipo, :material, :saneamiento, :agua, :luz, :drenaje, :tendencia, :direccion, :num_habitaciones, :num_banios, :idlocalidades, :idmunicipio)")
            stmt.bind_param(':tipo', tipo)
            stmt.bind_param(':material', material)
            stmt.bind_param(':saneamiento', saneamiento)
            stmt.bind_param(':agua', agua)
            stmt.bind_param(':luz', luz)
            stmt.bind_param(':drenaje', drenaje)
            stmt.bind_param(':tendencia', tendencia)
            stmt.bind_param(':direccion', direccion)
            stmt.bind_param(':num_habitaciones', num_habitaciones)
            stmt.bind_param(':num_banios', num_banios)
            stmt.bind_param(':idlocalidades', idlocalidades)
            stmt.bind_param(':idmunicipio', idmunicipio)
            stmt.execute()
            return True
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # SELECT TODAS VIVIENDA#
    ############################
    def seleccionarViviendas(self):
        try:
            stmt = self.db.prepare("SELECT * FROM vivienda")
            stmt.execute()
            viviendas = stmt.fetch_all(PDO.FETCH_ASSOC)

            return viviendas
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # SELECT VIVIENDA POR ID#
    ############################
    def seleccionarViviendaPorId(self, id):
        try:
            stmt = self.db.prepare("SELECT * FROM vivienda WHERE idvivienda = :id")
            stmt.bind_param(':id', id)
            stmt.execute()
            vivienda = stmt.fetch(PDO.FETCH_ASSOC)

            return vivienda
        except Exception as e:
            print(f"Error en la consulta SQL: {str(e)}")
            return False

    ############################
    # ACTUALIZAR LA ULTIMA VIVIENDA#
    ############################
    

    def actualizar_ultima_vivienda_agregada(tipo_vivienda, material, saneamiento, agua, luz, drenaje, tendencia, direccion, num_habitaciones, num_banios, idlocalidades, idmunicipio, idvivienda):
        try:
            connection = pymysql.connect(host=localhost;dbname=censopoblacion, root, '',
                                     user=root,
                                     password='',
                                     database= censpoblacion,
                                     charset='utf8mb4',
                                     cursorclass=pymysql.cursors.DictCursor)

            with connection.cursor() as cursor:
                sql = "UPDATE vivienda SET tipo_vivienda = %s, material = %s, saneamiento = %s, agua = %s, luz = %s, drenaje = %s, tendencia = %s, direccion = %s, num_habitaciones = %s, num_banios = %s, localidades_idlocalidades = %s, localidades_municipio_idmunicipio = %s WHERE idvivienda = %s"
                cursor.execute(sql, (tipo_vivienda, material, saneamiento, agua, luz, drenaje, tendencia, direccion, num_habitaciones, num_banios, idlocalidades, idmunicipio, idvivienda))
                connection.commit()
            return True
        except Exception as e:
            print("Error en la consulta SQL:", str(e))
            return False
        finally:
            connection.close()

    def borrar_ultima_vivienda_agregada():
        try:
            connection = pymysql.connect(host=localhost,
                                     user=root,
                                     password='',
                                     database=censopoblacion,
                                     charset='utf8mb4',
                                     cursorclass=pymysql.cursors.DictCursor)

            with connection.cursor() as cursor:
                sql = "DELETE FROM vivienda WHERE idvivienda = (SELECT MAX(idvivienda) FROM vivienda)"
                cursor.execute(sql)
                connection.commit()
            return True
        except Exception as e:
            print("Error en la consulta SQL:", str(e))
            return False
        finally:
            connection.close()
