class Vivienda:
    def __init__(self, idvivienda, tipo, material, saneamiento, agua, luz, drenaje, tendencia, direccion, numHabitaciones, numBanios, id_municipio, municipio, id_localidad, localidad, ubicacion, habitantes, ocupaciones):
        self.idvivienda = idvivienda
        self.tipo = tipo
        self.material = material
        self.saneamiento = saneamiento
        self.agua = agua
        self.luz = luz
        self.drenaje = drenaje
        self.tendencia = tendencia
        self.direccion = direccion
        self.numHabitaciones = numHabitaciones
        self.numBanios = numBanios
        self.id_municipio = id_municipio
        self.municipio = municipio
        self.id_localidad = id_localidad
        self.localidad = localidad
        self.ubicacion = ubicacion
        self.habitantes = habitantes
        self.ocupaciones = ocupaciones

    def getIdvivienda(self):
        return self.idvivienda

    def setIdvivienda(self, idvivienda):
        self.idvivienda = idvivienda
        return self

    def getTipo(self):
        return self.tipo

    def setTipo(self, tipo):
        self.tipo = tipo
        return self

    def getMaterial(self):
        return self.material

    def setMaterial(self, material):
        self.material = material
        return self

    def getSaneamiento(self):
        return self.saneamiento

    def setSaneamiento(self, saneamiento):
        self.saneamiento = saneamiento
        return self

    def getAgua(self):
        return self.agua

    def setAgua(self, agua):
        self.agua = agua
        return self

    def getLuz(self):
        return self.luz

    def setLuz(self, luz):
        self.luz = luz
        return self

    def getDrenaje(self):
        return self.drenaje

    def setDrenaje(self, drenaje):
        self.drenaje = drenaje
        return self

    def getTendencia(self):
        return self.tendencia

    def setTendencia(self, tendencia):
        self.tendencia = tendencia
        return self

    def getDireccion(self):
        return self.direccion

    def setDireccion(self, direccion):
        self.direccion = direccion
        return self

    def getNumHabitaciones(self):
        return self.numHabitaciones

    def setNumHabitaciones(self, numHabitaciones):
        self.numHabitaciones = numHabitaciones
        return self

    def getNumBanios(self):
        return self.numBanios

    def setNumBanios(self, numBanios):
        self.numBanios = numBanios
        return self

    def getIdMunicipio(self):
        return self.id_municipio

    def setIdMunicipio(self, id_municipio):
        self.id_municipio = id_municipio
        return self

    def getMunicipio(self):
        return self.municipio

    def setMunicipio(self, municipio):
        self.municipio = municipio
        return self

    def getIdLocalidad(self):
        return self.id_localidad

    def setIdLocalidad(self, id_localidad):
        self.id_localidad = id_localidad
        return self

    def getLocalidad(self):
        return self.localidad

    def setLocalidad(self, localidad):
        self.localidad = localidad
        return self

    def getUbicacion(self):
        return self.ubicacion

    def setUbicacion(self, ubicacion):
        self.ubicacion = ubicacion
        return self

    def getHabitantes(self):
        return self.habitantes

    def setHabitantes(self, habitantes):
        self.habitantes = habitantes
        return self

    def getOcupaciones(self):
        return self.ocupaciones

    def setOcupaciones(self, ocupaciones):
        self.ocupaciones = ocupaciones
        return self

    def agregarHabitante(self, habitante):
        # Verificar si el habitante ya existe en la lista
        if habitante not in self.habitantes:
            # Agregar el nuevo habitante a la lista
            self.habitantes.append(habitante)

    def agregarOcupacion(self, ocupacion):
        # Verificar si la ocupación ya existe en la lista
        if ocupacion not in self.ocupaciones:
            # Agregar la nueva ocupación a la lista
            self.ocupaciones.append(ocupacion)
