import sqlite3

class SingletonDB:
    _instance = None

    def __new__(cls):
        if not cls._instance:
            cls._instance = super(SingletonDB, cls).__new__(cls)
            cls._instance._db = sqlite3.connect(mysql:host=localhost;dbname=censopoblacion,root,'') 
        return cls._instance

    def get_db(self):
        return self._db

# Uso del SingletonDB
singleton_db = SingletonDB()
database_connection = singleton_db.get_db()

# Realiza operaciones con la conexión a la base de datos según sea necesario
